import { pulmonaryDemoRepo } from "../domains/pulmonary/repo";
import { cardiologyDemoRepo } from "../domains/cardiology/repo";
import { diabetesDemoRepo } from "../domains/diabetes/repo";

export const DEMO_REPOS = {
  pulmonary: pulmonaryDemoRepo,
  cardiology: cardiologyDemoRepo,
  diabetes: diabetesDemoRepo,
} as const;
