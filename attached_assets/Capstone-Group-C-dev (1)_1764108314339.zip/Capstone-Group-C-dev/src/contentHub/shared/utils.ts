import type { BaseContent, DomainSection } from "./base.types";

/**
 * Build horizontal sections by category.
 * Safe against undefined/null content or items.
 */
export function buildSections(
  content: BaseContent[] | undefined | null
): DomainSection[] {
  const safe = Array.isArray(content) ? content.filter(Boolean) : [];

  const cats = Array.from(new Set(safe.map((c) => c.category)));

  return cats.map((cat) => ({
    key: cat,
    data: safe.filter((c) => c.category === cat),
  }));
}
