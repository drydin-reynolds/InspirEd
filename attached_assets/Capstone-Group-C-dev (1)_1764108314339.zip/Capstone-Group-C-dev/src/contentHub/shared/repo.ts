import { BaseContent, DomainKey } from "./base.types";

export type HubQuery = {
  searchText?: string;
  categories?: string[];
  limit?: number;
};

export interface DomainRepo {
  domain: DomainKey;
  getAll(): Promise<BaseContent[]>;
  search(q: HubQuery): Promise<BaseContent[]>;
  getById(id: string): Promise<BaseContent | null>;
}
