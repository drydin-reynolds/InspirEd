export type BaseContent = {
  id: string;
  title: string;
  minutes: number;
  category: string;
  thumbnail: string;
  description: string;
  readBody: string;

  // optional future vector fields
  tags?: string[];
  embeddingId?: string;
};

export type DomainKey = "pulmonary" | "cardiology" | "diabetes";

export type DomainSection = {
  key: string;        // section title
  data: BaseContent[]; // items in section
};

export type HubPayload = {
  domain: DomainKey;
  content: BaseContent[];
  sections: DomainSection[];
  hero: BaseContent | null;
};
