import { useEffect, useMemo, useState } from "react";
import type { BaseContent, DomainKey } from "./shared/base.types";
import { buildSections } from "./shared/utils";
import { DEMO_REPOS } from "./demo";

type UseContentHubArgs = {
  domain: DomainKey;
};

export function useContentHub({ domain }: UseContentHubArgs) {
  const [content, setContent] = useState<BaseContent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;

    async function load() {
      setLoading(true);

      const repo = DEMO_REPOS[domain];

      // guard missing repo
      if (!repo) {
        console.warn(`[contentHub] No repo found for domain: ${domain}`);
        if (!alive) return;
        setContent([]);
        setLoading(false);
        return;
      }

      try {
        const all = await repo.getAll();

        if (!alive) return;

        // force array + strip undefined/null entries
        const safeAll = Array.isArray(all) ? all.filter(Boolean) : [];
        setContent(safeAll);
      } catch (e) {
        console.error(`[contentHub] Failed to load domain "${domain}":`, e);
        if (!alive) return;
        setContent([]);
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    }

    load();

    return () => {
      alive = false;
    };
  }, [domain]);

  const sections = useMemo(() => buildSections(content), [content]);
  const hero = useMemo(() => (content.length > 0 ? content[0] : null), [content]);

  return {
    domain,
    content,
    sections,
    hero,
    loading,
  };
}
