import { BaseContent } from "@/contentHub/shared/base.types";

export type PulmonaryContent = BaseContent;
