import { PULMONARY_DEMO } from "./demo";
import { DomainRepo } from "../../shared/repo";
import type { BaseContent } from "../../shared/base.types";

export const pulmonaryDemoRepo: DomainRepo = {
  domain: "pulmonary",

  async getAll(): Promise<BaseContent[]> {
    return PULMONARY_DEMO;
  },

  async search() {
    return PULMONARY_DEMO;
  },

  async getById(id: string) {
    return PULMONARY_DEMO.find((x) => x.id === id) ?? null;
  },
};
