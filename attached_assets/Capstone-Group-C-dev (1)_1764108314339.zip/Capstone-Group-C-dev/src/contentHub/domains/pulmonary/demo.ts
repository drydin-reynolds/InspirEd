// src/contentHub/domains/pulmonary/demo.ts
import { BaseContent } from "../../shared/base.types";
import { DomainRepo, HubQuery } from "../../shared/repo";
import { buildSections } from "../../shared/utils";

// 1) demo payload (your array is PERFECT; just type it BaseContent[])
export const PULMONARY_DEMO: BaseContent[] = [
  {
    id: "p1",
    title: "Breathing Basics",
    minutes: 6,
    category: "Getting Started",
    thumbnail:
      "https://images.unsplash.com/photo-1583912268180-1b523d5f1fe2?q=80&w=1200&auto=format&fit=crop",
    description:
      "Quick intro to how your lungs work, what normal breathing feels like, and why symptoms happen.",
    readBody:
      "In this module, you’ll learn the core ideas behind breathing: airways, alveoli, and oxygen exchange. We’ll also cover common signs of breathing trouble and when to get help.",
  },
  // ... rest unchanged
];

// 2) DEMO repo that matches DomainRepo exactly
export const pulmonaryDemoRepo: DomainRepo = {
  domain: "pulmonary",

  async getAll() {
    return PULMONARY_DEMO;
  },

  async search(q: HubQuery) {
    const { searchText, categories, limit } = q;

    let res = PULMONARY_DEMO;

    if (categories?.length) {
      res = res.filter((c) => categories.includes(c.category));
    }

    if (searchText?.trim()) {
      const t = searchText.toLowerCase();
      res = res.filter(
        (c) =>
          c.title.toLowerCase().includes(t) ||
          c.description.toLowerCase().includes(t) ||
          c.readBody.toLowerCase().includes(t)
      );
    }

    if (limit) res = res.slice(0, limit);

    return res;
  },

  async getById(id: string) {
    return PULMONARY_DEMO.find((c) => c.id === id) ?? null;
  },
};

// 3) optional helper if you want to reuse in useContentHub
export const pulmonaryDemoSections = buildSections(PULMONARY_DEMO);
export const pulmonaryDemoHero = PULMONARY_DEMO[0] ?? null;
