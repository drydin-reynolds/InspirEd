import { DomainRepo } from "../../shared/repo";
import type { BaseContent } from "../../shared/base.types";

export const diabetesDemoRepo: DomainRepo = {
  domain: "diabetes",

  async getAll(): Promise<BaseContent[]> {
    return [];
  },

  async search() {
    return [];
  },

  async getById() {
    return null;
  },
};
