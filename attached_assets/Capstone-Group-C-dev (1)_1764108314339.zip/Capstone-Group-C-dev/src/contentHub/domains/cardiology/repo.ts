import { DomainRepo } from "../../shared/repo";
import type { BaseContent } from "../../shared/base.types";

export const cardiologyDemoRepo: DomainRepo = {
  domain: "cardiology",

  async getAll(): Promise<BaseContent[]> {
    return [];
  },

  async search() {
    return [];
  },

  async getById() {
    return null;
  },
};
