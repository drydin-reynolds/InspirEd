import Summary from "@/screens/Summary";

export default function SummaryScreen() {
  return <Summary />;
}
