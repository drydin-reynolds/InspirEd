import Profile from "@/screens/Profile";

export default function ProfileScreen() {
  return <Profile />;
}
