import Signup from "@/screens/Signup";

export default function SignupScreen() {
  return <Signup />;
}
