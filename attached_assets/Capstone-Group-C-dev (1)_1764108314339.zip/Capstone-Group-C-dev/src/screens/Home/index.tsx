import { TextRegular, TextSemiBold } from "@/components/StyledText";
import { useSession } from "@/contexts/AuthContext";
import { useTheme } from "@/hooks/useTheme";
import { useUserData } from "@/stores/useUserStore";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { Stack, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  FlatList,
  Image,
  Pressable,
  Modal,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

import { useContentHub } from "@/contentHub/useContentHub";
import type { BaseContent } from "@/contentHub/shared/base.types";

// layout constants
const { width } = Dimensions.get("window");
const POSTER_W = Math.min(140, Math.round(width * 0.4));
const POSTER_H = Math.round(POSTER_W * 1.45);

export default function Home() {
  const { colors } = useTheme();
  const { signOut } = useSession(); // still here for future use
  const userData = useUserData();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const modalInsets = useSafeAreaInsets();

  // pulled from contentHub (demo now, vector DB later)
  const { sections, hero, loading } = useContentHub({ domain: "pulmonary" });

  // local UI state stays the same
  const [selected, setSelected] = useState<BaseContent | null>(null);
  const [mode, setMode] = useState<"watch" | "read">("watch");

  // fallback hero if empty (prevents crash)
  const safeHero = useMemo(() => hero ?? null, [hero]);

  return (
    <React.Fragment>
      <Stack.Screen
        options={{
          title: `Welcome Back, ${userData?.first_name ?? "Friend"}!`,
        }}
      />

      <SafeAreaView style={styles.root} edges={["top"]}>
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top ? 0 : 8 }]}>
          <Text style={styles.logo}>Pulmonary Care</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            <Pressable onPress={() => (router as any).push("/learn")}>
              <Ionicons name="library-outline" size={22} color="#fff" />
            </Pressable>
            <Pressable onPress={() => (router as any).push("/profile")}>
              <Ionicons name="person-circle-outline" size={24} color="#fff" />
            </Pressable>
          </View>
        </View>

        <ScrollView contentContainerStyle={{ paddingBottom: 32 }}>
          {/* Loading state */}
          {loading && (
            <View style={{ paddingTop: 24, alignItems: "center" }}>
              <ActivityIndicator />
              <Text style={{ color: "#999", marginTop: 8 }}>
                Loading content...
              </Text>
            </View>
          )}

          {/* Hero banner */}
          {!!safeHero && (
            <View style={styles.heroWrap}>
              <Image source={{ uri: safeHero.thumbnail }} style={styles.heroImg} />
              <LinearGradient
                colors={["rgba(0,0,0,0)", "rgba(0,0,0,0.75)"]}
                style={styles.heroGrad}
              />
              <View style={styles.heroTextBox}>
                <Text style={styles.heroTitle}>{safeHero.title}</Text>
                <Text style={styles.heroMeta}>
                  {safeHero.category} • {safeHero.minutes} min
                </Text>
                <View style={styles.heroBtns}>
                  <Pressable
                    onPress={() => {
                      setSelected(safeHero);
                      setMode("watch");
                    }}
                    style={[styles.btn, styles.btnPrimary]}
                  >
                    <Ionicons name="play" size={16} color="#000" />
                    <Text style={[styles.btnText, { color: "#000" }]}>
                      Watch
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={() => {
                      setSelected(safeHero);
                      setMode("read");
                    }}
                    style={[styles.btn, styles.btnGhost]}
                  >
                    <Ionicons name="book-outline" size={16} color="#fff" />
                    <Text style={styles.btnText}>Read</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          )}

          {/* Rows */}
          {sections.map((sec) => (
            <View key={sec.key} style={styles.rowWrap}>
              <Text style={styles.rowTitle}>{sec.key}</Text>
              <FlatList
                data={sec.data}
                keyExtractor={(it) => it.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ paddingHorizontal: 12 }}
                ItemSeparatorComponent={() => <View style={{ width: 10 }} />}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => {
                      setSelected(item);
                      setMode("watch");
                    }}
                    style={styles.card}
                  >
                    <Image source={{ uri: item.thumbnail }} style={styles.poster} />
                    <Text numberOfLines={1} style={styles.cardTitle}>
                      {item.title}
                    </Text>
                    <Text style={styles.cardMeta}>
                      {item.minutes} min · {item.category}
                    </Text>
                  </Pressable>
                )}
              />
            </View>
          ))}

          {/* Quick actions (keeps your old routes) */}
          <View style={styles.quickWrap}>
            <Text style={styles.rowTitle}>Quick Actions</Text>
            <View style={{ flexDirection: "row", gap: 10, paddingHorizontal: 12 }}>
              <Pressable
                style={[styles.quickBtn, { backgroundColor: "#8AB84A" }]}
                onPress={() => (router as any).push("/appointmentHistory")}
              >
                <Text style={styles.quickBtnText}>Visit History</Text>
              </Pressable>
              <Pressable
                style={[styles.quickBtn, { backgroundColor: "#3B82F6" }]}
                onPress={() => (router as any).push("/library")}
              >
                <Text style={styles.quickBtnText}>Resource Library</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>

        {/* Content modal (Watch / Read) */}
        <Modal
          visible={!!selected}
          animationType="slide"
          onRequestClose={() => setSelected(null)}
        >
          <View style={styles.modalRoot}>
            {/* Modal header */}
            <View style={[styles.modalHeader, { paddingTop: modalInsets.top + 8 }]}>
              <Pressable onPress={() => setSelected(null)} style={styles.iconBtn}>
                <Ionicons name="chevron-back" size={22} color="#fff" />
              </Pressable>
              <Text numberOfLines={1} style={styles.modalTitle}>
                {selected?.title}
              </Text>
              <View style={{ width: 36 }} />
            </View>

            {/* Tabs */}
            <View style={styles.tabs}>
              <Pressable
                onPress={() => setMode("watch")}
                style={[styles.tabBtn, mode === "watch" && styles.tabActive]}
              >
                <Ionicons
                  name="play"
                  size={14}
                  color={mode === "watch" ? "#000" : "#aaa"}
                />
                <Text style={[styles.tabText, mode === "watch" && styles.tabTextActive]}>
                  Watch
                </Text>
              </Pressable>

              <Pressable
                onPress={() => setMode("read")}
                style={[styles.tabBtn, mode === "read" && styles.tabActive]}
              >
                <Ionicons
                  name="book-outline"
                  size={14}
                  color={mode === "read" ? "#000" : "#aaa"}
                />
                <Text style={[styles.tabText, mode === "read" && styles.tabTextActive]}>
                  Read
                </Text>
              </Pressable>
            </View>

            {mode === "watch" ? (
              <View style={{ flex: 1, backgroundColor: "#000" }}>
                {/* Video placeholder for now */}
                <View style={styles.videoPlaceholder}>
                  <Ionicons name="play-circle" size={48} color="#fff" />
                  <Text style={{ color: "#fff", marginTop: 8, opacity: 0.8 }}>
                    Video coming soon
                  </Text>
                </View>

                <ScrollView style={{ flex: 1, padding: 16, backgroundColor: "#0b0b0b" }}>
                  <Text style={styles.desc}>{selected?.description}</Text>
                </ScrollView>
              </View>
            ) : (
              <ScrollView style={{ flex: 1, padding: 16, backgroundColor: "#0b0b0b" }}>
                <Text style={styles.readTitle}>{selected?.title}</Text>
                <Text style={styles.readMeta}>
                  {selected?.category} • {selected?.minutes} min read
                </Text>
                <Text style={styles.readBody}>{selected?.readBody}</Text>
              </ScrollView>
            )}
          </View>
        </Modal>
      </SafeAreaView>
    </React.Fragment>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#0b0b0b" },

  header: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    paddingTop: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#0b0b0b",
  },
  logo: { color: "#fff", fontSize: 22, fontWeight: "800", letterSpacing: 0.4 },

  heroWrap: { position: "relative", marginBottom: 8 },
  heroImg: { width: "100%", aspectRatio: 16 / 9 },
  heroGrad: { ...StyleSheet.absoluteFillObject },
  heroTextBox: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 16,
    gap: 6,
  },
  heroTitle: { color: "#fff", fontSize: 22, fontWeight: "800" },
  heroMeta: { color: "#e5e5e5", fontSize: 12 },
  heroBtns: { flexDirection: "row", gap: 10, marginTop: 6 },

  btn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 8,
  },
  btnPrimary: { backgroundColor: "#fff" },
  btnGhost: {
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.5)",
    backgroundColor: "rgba(255,255,255,0.05)",
  },
  btnText: { color: "#fff", fontWeight: "700" },

  rowWrap: { marginTop: 12 },
  rowTitle: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
    paddingHorizontal: 12,
    marginBottom: 8,
  },

  card: { width: POSTER_W },
  poster: {
    width: POSTER_W,
    height: POSTER_H,
    borderRadius: 10,
    backgroundColor: "#151515",
  },
  cardTitle: { color: "#fff", fontSize: 13, fontWeight: "600", marginTop: 6 },
  cardMeta: { color: "#b3b3b3", fontSize: 11, marginTop: 2 },

  quickWrap: { marginTop: 16 },
  quickBtn: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
  },
  quickBtnText: { color: "#fff", fontWeight: "700" },

  modalRoot: { flex: 1, backgroundColor: "#000" },
  modalHeader: {
    paddingTop: 0,
    paddingBottom: 8,
    paddingHorizontal: 8,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#0b0b0b",
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  modalTitle: { color: "#fff", fontSize: 16, fontWeight: "700", flex: 1 },

  tabs: {
    flexDirection: "row",
    gap: 8,
    padding: 8,
    backgroundColor: "#0b0b0b",
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: "#1f1f1f",
  },
  tabBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#2a2a2a",
  },
  tabActive: { backgroundColor: "#fff", borderColor: "#fff" },
  tabText: { color: "#aaa", fontSize: 12, fontWeight: "700" },
  tabTextActive: { color: "#000" },

  videoPlaceholder: {
    width: "100%",
    aspectRatio: 16 / 9,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
  },

  desc: { color: "#e6e6e6", fontSize: 14, lineHeight: 20 },
  readTitle: { color: "#fff", fontSize: 22, fontWeight: "800", marginBottom: 6 },
  readMeta: { color: "#d1d1d1", fontSize: 12, marginBottom: 12 },
  readBody: { color: "#e6e6e6", fontSize: 15, lineHeight: 22 },
});
