// Simple utility used by profile age input
function parseAge(input) {
  if (input === null || input === undefined) return null;
  const str = String(input);
  const digits = str.replace(/[^0-9]/g, "");
  return digits ? Number(digits) : null;
}

module.exports = { parseAge };
