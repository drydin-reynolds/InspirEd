// src/stores/storage.ts

type Value = string | number | boolean | undefined | null;

class FakeStorage {
  private map = new Map<string, string>();

  getString(key: string): string | undefined {
    return this.map.get(key);
  }

  getBoolean(key: string): boolean | undefined {
    const v = this.map.get(key);
    if (v === undefined) return undefined;
    return v === "true";
  }

  getNumber(key: string): number | undefined {
    const v = this.map.get(key);
    if (v === undefined) return undefined;
    const n = Number(v);
    return Number.isNaN(n) ? undefined : n;
  }

  set(key: string, value: Value) {
    if (value === undefined || value === null) {
      this.map.delete(key);
      return;
    }
    this.map.set(key, String(value));
  }

  delete(key: string) {
    this.map.delete(key);
  }
}

export const storage = new FakeStorage();