export interface IStorage {
  // Storage interface for future persistence needs
}

export class MemStorage implements IStorage {
  constructor() {
    // In-memory storage - recordings are ephemeral (session-based)
  }
}

export const storage = new MemStorage();
