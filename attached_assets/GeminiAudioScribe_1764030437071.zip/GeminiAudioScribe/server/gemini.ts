import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function transcribeAudio(
  audioBase64: string,
  mimeType: string
): Promise<{ transcription: string; summary: string }> {
  try {
    const audioBytes = Buffer.from(audioBase64, "base64");

    const transcriptionContents = [
      {
        inlineData: {
          data: audioBytes.toString("base64"),
          mimeType: mimeType,
        },
      },
      `Transcribe this audio file. Provide a complete, accurate transcription of everything that was said. 
Do not add any commentary or additional text - just the transcription.`,
    ];

    const transcriptionResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: transcriptionContents,
    });

    const transcription = transcriptionResponse.text || "";

    if (!transcription) {
      throw new Error("No transcription generated");
    }

    const summaryContents = [
      {
        inlineData: {
          data: audioBytes.toString("base64"),
          mimeType: mimeType,
        },
      },
      `Analyze this audio and provide a concise summary that includes:
- Main topic or theme
- Key points discussed (as bullet points)
- Important details or action items
- Overall context

Format the summary in a clear, readable way with proper paragraphs and bullet points where appropriate.`,
    ];

    const summaryResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: summaryContents,
    });

    const summary = summaryResponse.text || "";

    return {
      transcription,
      summary,
    };
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error(`Failed to process audio: ${error}`);
  }
}
