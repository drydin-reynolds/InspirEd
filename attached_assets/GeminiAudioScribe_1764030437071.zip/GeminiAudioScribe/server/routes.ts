import type { Express } from "express";
import { createServer, type Server } from "http";
import { transcribeAudio } from "./gemini";
import { transcriptionRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/transcribe", async (req, res) => {
    try {
      const validatedData = transcriptionRequestSchema.parse(req.body);
      
      const result = await transcribeAudio(
        validatedData.audioData,
        validatedData.mimeType
      );

      res.json(result);
    } catch (error) {
      console.error("Transcription error:", error);
      res.status(500).json({ 
        error: "Failed to transcribe audio",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
