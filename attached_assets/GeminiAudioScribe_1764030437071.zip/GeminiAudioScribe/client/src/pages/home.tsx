import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Mic, Square, Play, Pause, Download, Copy, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Home() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcription, setTranscription] = useState<string>("");
  const [summary, setSummary] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioLevels, setAudioLevels] = useState<number[]>(Array(20).fill(0));

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const visualizeAudio = (stream: MediaStream) => {
    const audioContext = new AudioContext();
    const analyser = audioContext.createAnalyser();
    const source = audioContext.createMediaStreamSource(stream);
    
    analyser.fftSize = 64;
    source.connect(analyser);
    
    audioContextRef.current = audioContext;
    analyserRef.current = analyser;

    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    
    const updateLevels = () => {
      if (!analyserRef.current || !isRecording) return;
      
      analyser.getByteFrequencyData(dataArray);
      const levels = Array.from(dataArray.slice(0, 20)).map(v => v / 255);
      setAudioLevels(levels);
      
      animationFrameRef.current = requestAnimationFrame(updateLevels);
    };
    
    updateLevels();
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
        const url = URL.createObjectURL(blob);
        setAudioURL(url);
        setAudioBlob(blob);
        setDuration(recordingTime);
        
        stream.getTracks().forEach(track => track.stop());
        
        if (audioContextRef.current) {
          audioContextRef.current.close();
        }
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setRecordingTime(0);
      
      visualizeAudio(stream);

      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      toast({
        title: "Recording started",
        description: "Speak clearly into your microphone",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not access microphone. Please grant permission.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      
      setAudioLevels(Array(20).fill(0));
    }
  };

  const togglePlayPause = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const processAudio = async () => {
    if (!audioBlob) return;

    setIsProcessing(true);
    setTranscription("");
    setSummary("");

    try {
      const base64Audio = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (reader.result) {
            const base64 = (reader.result as string).split(',')[1];
            resolve(base64);
          } else {
            reject(new Error('Failed to read audio file'));
          }
        };
        reader.onerror = () => reject(new Error('Failed to read audio file'));
        reader.readAsDataURL(audioBlob);
      });

      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          audioData: base64Audio,
          mimeType: audioBlob.type,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Transcription failed' }));
        throw new Error(errorData.error || 'Transcription failed');
      }

      const data = await response.json();
      setTranscription(data.transcription);
      setSummary(data.summary);

      toast({
        title: "Success",
        description: "Audio processed successfully",
      });
    } catch (error) {
      console.error('Processing error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to process audio. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: `${label} copied to clipboard`,
    });
  };

  const downloadAudio = () => {
    if (!audioURL) return;
    
    const a = document.createElement('a');
    a.href = audioURL;
    a.download = `recording-${Date.now()}.webm`;
    a.click();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card border-card-border sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-primary flex items-center justify-center">
              <Mic className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-semibold" data-testid="text-app-title">Voice Transcribe</h1>
          </div>
          <Badge variant="outline" data-testid="badge-status">
            {isRecording ? "Recording" : audioBlob ? "Ready to Process" : "Ready"}
          </Badge>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-8 py-6 sm:py-8">
        <div className="grid gap-6 md:grid-cols-[2fr_3fr]">
          <div className="space-y-6">
            <Card data-testid="card-recorder">
              <CardHeader>
                <CardTitle className="text-2xl">Recording</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center gap-6">
                  {isRecording && (
                    <div className="text-center space-y-2">
                      <div className="text-3xl font-semibold font-mono" data-testid="text-recording-time">
                        {formatTime(recordingTime)}
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-destructive animate-pulse" data-testid="indicator-recording" />
                        <span className="text-sm text-muted-foreground">Recording</span>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-center items-end h-16 w-full gap-1">
                    {audioLevels.map((level, i) => (
                      <div
                        key={i}
                        className="w-full bg-primary rounded-t transition-all duration-75"
                        style={{
                          height: `${Math.max(4, level * 100)}%`,
                          opacity: isRecording ? 0.6 + level * 0.4 : 0.2,
                        }}
                      />
                    ))}
                  </div>

                  <div className="flex gap-4">
                    {!isRecording ? (
                      <Button
                        size="lg"
                        className="w-24 h-24 rounded-full"
                        onClick={startRecording}
                        data-testid="button-start-recording"
                      >
                        <Mic className="w-8 h-8" />
                      </Button>
                    ) : (
                      <Button
                        size="lg"
                        variant="destructive"
                        className="w-24 h-24 rounded-full"
                        onClick={stopRecording}
                        data-testid="button-stop-recording"
                      >
                        <Square className="w-8 h-8" />
                      </Button>
                    )}
                  </div>

                  {!isRecording && !audioBlob && (
                    <p className="text-sm text-muted-foreground text-center max-w-xs" data-testid="text-instructions">
                      Click the microphone button to start recording your audio
                    </p>
                  )}
                </div>

                {audioURL && (
                  <div className="space-y-4 pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Playback</span>
                      <span className="text-sm text-muted-foreground font-mono" data-testid="text-duration">
                        {formatTime(duration)}
                      </span>
                    </div>
                    
                    <audio
                      ref={audioRef}
                      src={audioURL}
                      onEnded={() => setIsPlaying(false)}
                      className="hidden"
                    />

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={togglePlayPause}
                        data-testid="button-play-pause"
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={downloadAudio}
                        data-testid="button-download-audio"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>

                    <Button
                      className="w-full"
                      onClick={processAudio}
                      disabled={isProcessing}
                      data-testid="button-process-audio"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        "Transcribe & Summarize"
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            {isProcessing && (
              <Card data-testid="card-processing">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center gap-4 py-8">
                    <Loader2 className="w-12 h-12 animate-spin text-primary" />
                    <div className="text-center space-y-2">
                      <p className="font-medium">Processing your audio</p>
                      <p className="text-sm text-muted-foreground">
                        Transcribing and generating summary...
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {transcription && (
              <Card data-testid="card-transcription">
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle>Transcription</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(transcription, "Transcription")}
                    data-testid="button-copy-transcription"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div 
                    className="prose prose-sm max-w-none leading-relaxed"
                    data-testid="text-transcription"
                  >
                    {transcription}
                  </div>
                </CardContent>
              </Card>
            )}

            {summary && (
              <Card data-testid="card-summary">
                <CardHeader className="flex flex-row items-center justify-between gap-2">
                  <CardTitle>Summary</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(summary, "Summary")}
                    data-testid="button-copy-summary"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div 
                    className="space-y-4 text-sm leading-relaxed"
                    data-testid="text-summary"
                  >
                    {summary.split('\n').map((paragraph, i) => (
                      paragraph.trim() && (
                        <p key={i} className="text-foreground">
                          {paragraph}
                        </p>
                      )
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {!isProcessing && !transcription && !audioBlob && (
              <Card data-testid="card-empty-state">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center gap-4 py-12 text-center">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                      <Mic className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold text-lg">No recording yet</h3>
                      <p className="text-sm text-muted-foreground max-w-sm">
                        Start recording to see your transcription and AI-generated summary appear here
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
