# Design Guidelines: Audio Recording & Transcription App

## Design Approach
**System Selected:** Material Design 3 with inspiration from productivity tools like Otter.ai and Descript
**Rationale:** This utility-focused application requires clarity, immediate usability, and clear visual feedback for recording states. Material Design 3 provides excellent component patterns for status indicators, controls, and content hierarchy.

## Typography Hierarchy
- **Display:** Inter or Roboto, 600 weight, 2xl-3xl for main headings
- **Body Text:** Inter or Roboto, 400 weight, base size for transcription content
- **Labels:** 500 weight, sm size for control labels and metadata
- **Monospace:** JetBrains Mono for timestamps and technical info

## Layout System
**Spacing Units:** Tailwind units of 2, 4, 6, and 8 (p-4, m-6, gap-8, etc.)
**Container:** max-w-6xl centered with px-4 on mobile, px-8 on desktop

**Main Layout Structure:**
- Single-column on mobile (< 768px)
- Two-column split on desktop: 40% left (controls/recording), 60% right (results)
- Persistent header with app title and settings icon
- Full-height layout utilizing available viewport space

## Core Components

### Recording Control Panel
- Large circular record button (w-20 h-20 on mobile, w-24 h-24 on desktop)
- Recording duration timer prominently displayed above button
- Visual waveform indicator during recording (animated bars, h-16)
- Status badges: "Ready" | "Recording" | "Processing"
- Secondary controls below: pause, stop (when active)
- Spacing: p-8 around control group, gap-6 between elements

### Audio Playback Module
- Horizontal waveform visualization (h-24)
- Play/pause button (w-12 h-12)
- Time scrubber with current/total duration
- Volume control slider
- Download recorded audio button
- Spacing: p-6, gap-4 between controls

### Transcription Display
- Clean text area with max-w-prose for readability
- Line height: leading-relaxed (1.625)
- Speaker labels (if applicable) with subtle distinction
- Timestamp markers every 30 seconds
- Spacing: p-6, mb-4 between paragraphs

### Summary Panel
- Distinct visual container (border or subtle shadow)
- "Key Points" heading with bullet list
- "Summary" heading with paragraph text
- "Topics" section with tag-style chips
- Spacing: p-8, gap-6 between sections

### Status Indicators
- Recording state: pulsing dot indicator (w-3 h-3 with animation)
- Processing: spinner with "Transcribing..." or "Generating summary..." text
- Success/Error: toast notifications (top-right, p-4)
- Real-time character count during transcription

### Navigation Header
- Fixed position, h-16
- App logo/title on left
- Action icons on right: history, settings (w-6 h-6)
- Subtle bottom border for separation
- Spacing: px-6, flex justify-between

### Empty States
- Centered content with microphone icon (w-16 h-16)
- Instructional text: "Click record to start capturing audio"
- Supporting text explaining features
- Spacing: py-16, gap-4

## Interaction Patterns
- **Recording Button:** Scale transform on press (scale-95), clear active state
- **Waveform:** Real-time amplitude visualization, 20-30 bars
- **Loading States:** Skeleton loaders for transcription/summary sections
- **Scroll Behavior:** Sticky header, auto-scroll to new transcription content
- **Copy Actions:** One-click copy buttons for transcription and summary

## Component Specifications

**Buttons:**
- Primary (Record): Large, rounded-full, shadow-lg
- Secondary (Controls): Medium, rounded-lg
- Icon buttons: p-2, rounded-md with hover effect

**Cards/Panels:**
- Rounded-xl corners
- Border or subtle shadow for definition
- p-6 to p-8 internal padding

**Form Elements:**
- File upload zone (if allowing upload): border-2 dashed, p-12, rounded-lg
- Settings inputs: Standard material inputs with floating labels

**Lists:**
- Previous recordings list: gap-3, each item with p-4, rounded-lg
- Show duration, date, and quick action icons

## Responsive Behavior
- **Mobile (< 768px):** 
  - Stack all sections vertically
  - Full-width recording controls
  - Collapsed playback controls (expand on demand)
  - p-4 general padding

- **Desktop (≥ 768px):**
  - Two-panel layout with persistent visibility
  - Larger control surfaces
  - p-8 general padding
  - max-w-6xl container

## Accessibility
- ARIA labels for all icon buttons
- Live region announcements for recording status changes
- Keyboard shortcuts: Space (record/pause), Escape (stop)
- Focus indicators on all interactive elements
- Sufficient contrast ratios (will be addressed in visual treatment)

## Animation Guidelines
**Use Sparingly:**
- Recording pulse indicator (subtle, 1.5s duration)
- Waveform bars (real-time, smooth transitions)
- Loading spinners (standard Material rotation)
- No scroll animations, parallax, or decorative motion

This utility-focused design prioritizes clarity, immediate feedback, and efficient workflow for capturing, reviewing, and processing audio content.