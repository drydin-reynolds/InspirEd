import { z } from "zod";

export interface Recording {
  id: string;
  audioBlob: Blob;
  duration: number;
  timestamp: Date;
  transcription?: string;
  summary?: string;
  isProcessing: boolean;
}

export const transcriptionRequestSchema = z.object({
  audioData: z.string(),
  mimeType: z.string(),
});

export const transcriptionResponseSchema = z.object({
  transcription: z.string(),
  summary: z.string(),
});

export type TranscriptionRequest = z.infer<typeof transcriptionRequestSchema>;
export type TranscriptionResponse = z.infer<typeof transcriptionResponseSchema>;
