# Voice Transcribe - Audio Recording & AI Transcription App

## Overview
Voice Transcribe is a browser-based application that enables users to record audio, transcribe it using AI, and generate intelligent summaries. Built with React, Express.js, and powered by Google's Gemini 2.5 Flash model.

## Current State (November 25, 2025)
The application is fully functional with all MVP features implemented and tested.

## Features Implemented

### Core Functionality
- **Browser-based Audio Recording**: Record audio directly in the browser using the MediaRecorder API
- **Real-time Audio Visualization**: Animated waveform display showing audio levels during recording
- **Audio Playback**: Review recordings before processing
- **AI-Powered Transcription**: Accurate speech-to-text using Gemini 2.5 Flash
- **Intelligent Summarization**: AI-generated summaries with key points and context
- **Clean, Intuitive UI**: Material Design 3 inspired interface with proper spacing and visual hierarchy

### Technical Features
- Recording timer with formatted display (MM:SS)
- Status indicators (Ready, Recording, Processing)
- Copy to clipboard for transcription and summary
- Download recorded audio files
- Comprehensive error handling with user-friendly toast notifications
- Loading states with spinner animations
- Responsive design (mobile and desktop optimized)

## Architecture

### Frontend
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with custom design tokens
- **UI Components**: Shadcn UI component library
- **State Management**: React hooks (useState, useRef, useEffect)
- **Audio APIs**: MediaRecorder API, Web Audio API for visualization
- **Routing**: Wouter for client-side routing

### Backend
- **Framework**: Express.js
- **AI Integration**: Google Gemini API (@google/genai)
- **Validation**: Zod schemas for request validation
- **Error Handling**: Comprehensive try-catch with detailed error messages

### Data Flow
1. User records audio → MediaRecorder captures audio stream
2. Recording stops → Audio blob created and stored in memory
3. User clicks "Transcribe & Summarize" → Audio converted to base64
4. Frontend sends POST request to /api/transcribe
5. Backend processes audio with Gemini (two API calls: transcription + summary)
6. Results returned to frontend and displayed in organized cards

## Project Structure
```
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── home.tsx          # Main app page with recording UI
│   │   │   └── not-found.tsx     # 404 page
│   │   ├── components/ui/        # Shadcn UI components
│   │   ├── hooks/                # Custom React hooks
│   │   ├── lib/                  # Utility functions and query client
│   │   ├── App.tsx               # App router and providers
│   │   └── index.css             # Global styles with design tokens
│   └── index.html                # HTML entry point with SEO meta tags
├── server/
│   ├── routes.ts                 # API route definitions
│   ├── gemini.ts                 # Gemini API integration
│   ├── app.ts                    # Express app configuration
│   └── storage.ts                # Storage interface (currently in-memory)
└── shared/
    └── schema.ts                 # Shared TypeScript types and Zod schemas
```

## API Endpoints

### POST /api/transcribe
Transcribes and summarizes audio data using Gemini AI.

**Request Body:**
```json
{
  "audioData": "base64_encoded_audio_data",
  "mimeType": "audio/webm;codecs=opus"
}
```

**Response:**
```json
{
  "transcription": "Full transcription text...",
  "summary": "AI-generated summary with key points..."
}
```

**Error Response:**
```json
{
  "error": "Error message",
  "details": "Detailed error information"
}
```

## Environment Variables
- `GEMINI_API_KEY` (required): Google AI Studio API key for Gemini access
- `PORT` (optional): Server port (defaults to 5000)

## Design System

### Typography
- Primary font: Inter (sans-serif)
- Monospace font: JetBrains Mono
- Font sizes: Tailwind default scale with semantic usage

### Color Palette
- Primary: Blue (210° hue) for interactive elements and branding
- Backgrounds: Neutral grays with subtle elevation
- Status colors: Destructive red for recording indicator
- Text hierarchy: foreground, muted-foreground for secondary text

### Spacing
- Base unit: 0.25rem (Tailwind spacing scale)
- Component padding: p-6 to p-8 for cards
- Gap between elements: gap-4 to gap-6

### Components
- Cards: Rounded corners (rounded-xl), subtle borders
- Buttons: Multiple variants (default, outline, ghost, destructive)
- Badges: Outline variant for status indicators
- Icons: Lucide React icon library

## Recent Changes (Latest Session)

### Bug Fixes
1. Fixed async/await issue in processAudio function - wrapped FileReader in Promise
2. Increased Express JSON body size limit to 25MB for large audio files
3. Improved error handling with proper error propagation to UI
4. Added detailed error messages in toast notifications

### Code Quality Improvements
- Added proper TypeScript typing throughout
- Implemented Zod schema validation for API requests
- Organized components with clear separation of concerns
- Added comprehensive data-testid attributes for testing

## Known Limitations
- Recordings are ephemeral (not persisted to database)
- No support for uploading pre-recorded audio files
- Maximum recording length limited by browser memory
- Gemini API may take 10-30 seconds to process longer recordings
- Automated tests cannot access browser microphone (expected limitation)

## Development

### Running the App
```bash
npm run dev
```
Server runs on port 5000, serving both API and frontend.

### Testing Notes
- Manual testing required for audio recording features
- Automated tests blocked by browser microphone permissions (expected)
- All UI elements have proper test IDs for future test implementation

## Future Enhancements (Agreed Upon)
- Add ability to save and manage multiple recordings with timestamps
- Implement export functionality for transcriptions and summaries (PDF, TXT)
- Add speaker identification for multi-person conversations
- Create summary customization options (length, format, focus areas)
- Enable batch processing of multiple audio files

## User Preferences
- Clean, professional interface prioritized over decorative elements
- Focus on utility and clarity in design decisions
- Material Design 3 principles for consistency
